//
//  AppDelegate.h
//  Hype2XcodeTemplate
//
//  Created by Nick Gressle on 5/12/16.
//  Copyright © 2016 nick gressle illustrations LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

