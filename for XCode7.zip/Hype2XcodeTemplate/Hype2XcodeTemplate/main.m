//
//  main.m
//  Hype2XcodeTemplate
//
//  Created by Nick Gressle on 5/12/16.
//  Copyright © 2016 nick gressle illustrations LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
