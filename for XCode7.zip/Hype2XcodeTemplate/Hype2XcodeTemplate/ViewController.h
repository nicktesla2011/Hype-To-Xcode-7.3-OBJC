//
//  ViewController.h
//  template
//
//  Created by YOU on 00/00/00.
//  Copyright (c) 2015 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *Webview;

@end